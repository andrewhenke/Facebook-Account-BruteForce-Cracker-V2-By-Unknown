﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Les informations générales relatives à un assembly dépendent de
' l'ensemble d'attributs suivant. Changez les valeurs de ces attributs pour modifier les informations
' associées à un assembly.

' Vérifiez les valeurs des attributs de l'assembly

<Assembly: AssemblyTitle("Facebook Bruteforce Attack V2 By Unknown")>
<Assembly: AssemblyDescription("Facebook Bruteforce Attack V2 By Unknown")>
<Assembly: AssemblyCompany("Facebook Bruteforce Attack V2 By Unknown")>
<Assembly: AssemblyProduct("Facebook Bruteforce Attack V2 By Unknown")>
<Assembly: AssemblyCopyright("Copyright ©  2019")>
<Assembly: AssemblyTrademark("Facebook")>

<Assembly: ComVisible(False)>

'Le GUID suivant est pour l'ID de la typelib si ce projet est exposé à COM
<Assembly: Guid("c4de53ae-a2ac-4fbe-af15-0d521ee01e07")>

' Les informations de version pour un assembly se composent des quatre valeurs suivantes :
'
'      Version principale
'      Version secondaire
'      Numéro de build
'      Révision
'
' Vous pouvez spécifier toutes les valeurs ou indiquer les numéros de build et de révision par défaut
' en utilisant '*', comme indiqué ci-dessous :
' <Assembly: AssemblyVersion("1.0.*")>

<Assembly: AssemblyVersion("5.1.3.2")>
<Assembly: AssemblyFileVersion("1.9.7.4")>
